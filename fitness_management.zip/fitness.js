document.addEventListener('DOMContentLoaded', function() {
    // Hero section email form submission
    const emailForm = document.querySelector('#hero .email-form');
    if (emailForm) {
        emailForm.addEventListener('submit', function(event) {
            event.preventDefault();
            const emailInput = emailForm.querySelector('input[type="email"]');
            const emailValue = emailInput.value;

            if (emailValue) {
                alert(`Thank you for signing up with email: ${emailValue}`);
                emailInput.value = '';
            } else {
                alert('Please enter your email.');
            }
        });
    }

    // BMI Calculator form submission
    const bmiForm = document.getElementById('bmi-form');
    if (bmiForm) {
        bmiForm.addEventListener('submit', function(event) {
            event.preventDefault();
            const height = parseFloat(document.getElementById('height').value) / 100; // Convert cm to meters
            const weight = parseFloat(document.getElementById('weight').value);

            if (isNaN(height) || isNaN(weight) || height <= 0 || weight <= 0) {
                alert('Please enter valid height and weight.');
                return;
            }

            const bmi = weight / (height * height);
            const bmiResult = bmi.toFixed(2);

            let interpretation = '';
            if (bmi < 18.5) {
                interpretation = 'Underweight';
            } else if (bmi < 25) {
                interpretation = 'Normal weight';
            } else if (bmi < 30) {
                interpretation = 'Overweight';
            } else {
                interpretation = 'Obese';
            }

            document.getElementById('bmi-result').innerHTML = `Your BMI is: ${bmiResult} (${interpretation})`;
        });
    }
});
const express = require('express');
const oracledb = require('oracledb');
const cors = require('cors');

const app = express();
const port = 3000;

app.use(cors());

// Database credentials
const dbConfig = {
    user: "system",
    password: "aadit123",
    connectString: "localhost:1521/ORCL" // Replace with your connect string
};

// API endpoint to fetch users
app.get('/users', async (req, res) => {
    let connection;

    try {
        connection = await oracledb.getConnection(dbConfig);
        const result = await connection.execute(
            `SELECT user_id, name, age, gender FROM Users`,
            [], // No bind variables
            { outFormat: oracledb.OUT_FORMAT_OBJECT } // Return rows as objects
        );
        res.json(result.rows);
    } catch (err) {
        console.error(err);
        res.status(500).send('Database error');
    } finally {
        if (connection) {
            try {
                await connection.close();
            } catch (err) {
                console.error(err);
            }
        }
    }
});

// Start the server
app.listen(port, () => {
    console.log(`Server listening at http://localhost:${port}`);
});
app.use(cors());
